bakeqtpi
========

Clone of bakeqtpi from https://gitorious.org/bakeqtpi that is target to release qt5 packages